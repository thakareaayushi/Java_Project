package com.ty.springwithEmployeeData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwithEmployeeDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
