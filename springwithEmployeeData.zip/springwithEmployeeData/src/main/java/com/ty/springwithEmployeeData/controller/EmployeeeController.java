package com.ty.springwithEmployeeData.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.ty.springwithEmployeeData.dto.Employee;
import com.ty.springwithEmployeeData.dto.ResponseStructure;
import com.ty.springwithEmployeeData.repository.EmployeeRepository;

@RestController
public class EmployeeeController {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@PostMapping("/employee")
	public Employee saveEmployee(@RequestBody Employee employee) {
		employeeRepository.save(employee);
		System.out.println("save");
		return employee;
	}
	@GetMapping("/employee")
	public List<Employee> getAllStudent(){
		List<Employee> employeeList=employeeRepository.findAll();
	    return employeeList;
	}
	@GetMapping("/employee/{id}")
	public Employee getEtudentById(@PathVariable int id) {
		Optional<Employee> employee=employeeRepository.findById(id);
	    if(employee.isPresent()) {
	    	return employee.get();
	    }
	    else
	    {
	    	return null;
	    }
	   
	   }
	@DeleteMapping("/employee/{id}")
	public Employee deleteStudent(@PathVariable int id) {
		 employeeRepository.deleteById(id);
		 System.out.println("delete sucessfully");
		 return null;
	}
	 @PutMapping("/employee")
	 public Employee updateStudent(@RequestBody Employee employee) {
		 employeeRepository.save(employee);
		 return employee;
	 }
	
	

}

